package birds;

public class DataKey {

    
	// default constructor
	public DataKey() {
	 
	}
        
	// other constructors

	/**
	 * Returns 0 if this DataKey is equal to k, returns -1 if this DataKey is smaller
	 * than k, and it returns 1 otherwise. 
	 */
	public int compareTo(DataKey k) {
           return 0;
            
	}
}

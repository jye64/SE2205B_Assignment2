package birds;

/**
 * This class represents a bird record in the database. Each record consists of two
 * parts: a DataKey and the data associated with the DataKey.
 */
public class BirdRecord {

 

    // default constructor
    public BirdRecord() {
       
        
    }

     // Other constructors
 


}
